# IndividualProject2

A webapp showing proficiency with vue.js. express and mongodb.

github link >> https://github.com/wednesday-256/IndividualProject2

github pages link >> https://wednesday-256.github.io/IndividualProject2/
